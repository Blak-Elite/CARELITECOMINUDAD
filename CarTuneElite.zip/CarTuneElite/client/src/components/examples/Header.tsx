import { useState } from 'react';
import Header from '../Header';
import { ThemeProvider } from '../ThemeProvider';

export default function HeaderExample() {
  const [showZonaElite, setShowZonaElite] = useState(false);

  const handleZonaEliteClick = () => {
    setShowZonaElite(true);
    setTimeout(() => setShowZonaElite(false), 3000);
  };

  return (
    <ThemeProvider>
      <div className="min-h-screen bg-background">
        <Header onZonaEliteClick={handleZonaEliteClick} />
        
        <main className="max-w-4xl mx-auto p-6">
          {showZonaElite ? (
            <div className="text-center py-12">
              <h2 className="text-xl font-bold text-primary mb-2">ZONA-ELITE Clicked!</h2>
              <p className="text-muted-foreground">This would open the admin login modal</p>
            </div>
          ) : (
            <div id="vehicle-config" className="text-center py-12">
              <h2 className="text-xl font-bold text-foreground mb-2">Configuration Section</h2>
              <p className="text-muted-foreground">This is where the vehicle configuration form would appear</p>
            </div>
          )}
        </main>
      </div>
    </ThemeProvider>
  );
}