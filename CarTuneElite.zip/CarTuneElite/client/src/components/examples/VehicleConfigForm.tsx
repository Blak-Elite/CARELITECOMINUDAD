import VehicleConfigForm from '../VehicleConfigForm';

export default function VehicleConfigFormExample() {
  return (
    <div className="min-h-screen bg-background p-4">
      <VehicleConfigForm />
    </div>
  );
}