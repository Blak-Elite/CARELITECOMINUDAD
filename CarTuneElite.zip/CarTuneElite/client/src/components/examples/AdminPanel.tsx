import { useState } from 'react';
import { Button } from '@/components/ui/button';
import AdminPanel from '../AdminPanel';

export default function AdminPanelExample() {
  const [showPanel, setShowPanel] = useState(true);
  const [showLoggedOut, setShowLoggedOut] = useState(false);

  const handleLogout = () => {
    setShowPanel(false);
    setShowLoggedOut(true);
    setTimeout(() => {
      setShowLoggedOut(false);
      setShowPanel(true);
    }, 3000);
  };

  if (showLoggedOut) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-bold text-foreground mb-2">Sesión Cerrada</h2>
          <p className="text-muted-foreground">Regresando al panel...</p>
        </div>
      </div>
    );
  }

  if (!showPanel) {
    return (
      <div className="min-h-screen bg-background p-4 flex items-center justify-center">
        <Button onClick={() => setShowPanel(true)} variant="outline" className="hover-elevate">
          Mostrar Panel Admin
        </Button>
      </div>
    );
  }

  return <AdminPanel onLogout={handleLogout} />;
}