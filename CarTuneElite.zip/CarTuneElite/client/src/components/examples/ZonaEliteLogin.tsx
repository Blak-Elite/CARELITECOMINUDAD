import { useState } from 'react';
import { Button } from '@/components/ui/button';
import ZonaEliteLogin from '../ZonaEliteLogin';

export default function ZonaEliteLoginExample() {
  const [isOpen, setIsOpen] = useState(true);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleSuccess = () => {
    setIsOpen(false);
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
  };

  return (
    <div className="min-h-screen bg-background p-4 flex items-center justify-center">
      {!showSuccess && (
        <Button 
          onClick={() => setIsOpen(true)}
          variant="outline"
          className="hover-elevate"
        >
          Abrir ZONA-ELITE
        </Button>
      )}
      
      {showSuccess && (
        <div className="text-center">
          <h2 className="text-xl font-bold text-primary mb-2">¡Acceso Concedido!</h2>
          <p className="text-muted-foreground">Bienvenido a ZONA-ELITE</p>
        </div>
      )}
      
      <ZonaEliteLogin 
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        onSuccess={handleSuccess}
      />
    </div>
  );
}