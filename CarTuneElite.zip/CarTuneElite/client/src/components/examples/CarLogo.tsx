import CarLogo from '../CarLogo';

export default function CarLogoExample() {
  return (
    <div className="flex gap-4 items-center bg-background p-4">
      <CarLogo size="sm" />
      <CarLogo size="md" />
      <CarLogo size="lg" />
    </div>
  );
}