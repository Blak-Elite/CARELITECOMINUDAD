import { Button } from '@/components/ui/button';
import { Moon, Sun } from 'lucide-react';
import { ThemeProvider, useTheme } from '../ThemeProvider';

function ThemeToggle() {
  const { theme, setTheme } = useTheme();

  return (
    <Button
      variant="outline"
      size="icon"
      onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
      className="hover-elevate"
      data-testid="button-theme-toggle"
    >
      {theme === 'light' ? (
        <Moon className="w-4 h-4" />
      ) : (
        <Sun className="w-4 h-4" />
      )}
    </Button>
  );
}

export default function ThemeProviderExample() {
  return (
    <ThemeProvider defaultTheme="dark">
      <div className="min-h-screen bg-background p-8">
        <div className="max-w-2xl mx-auto space-y-8">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-foreground">Theme Demo</h1>
            <ThemeToggle />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-card p-4 rounded-lg border border-card-border">
              <h3 className="font-semibold text-card-foreground mb-2">Card Component</h3>
              <p className="text-muted-foreground text-sm">This card adapts to theme changes</p>
            </div>
            
            <div className="bg-primary/10 p-4 rounded-lg border border-primary/20">
              <h3 className="font-semibold text-primary mb-2">Primary Color</h3>
              <p className="text-foreground text-sm">Accent colors work in both themes</p>
            </div>
          </div>
        </div>
      </div>
    </ThemeProvider>
  );
}