import { Button } from '@/components/ui/button';
import { Moon, Sun, Settings } from 'lucide-react';
import { useTheme } from './ThemeProvider';
import CarLogo from './CarLogo';

interface HeaderProps {
  onZonaEliteClick: () => void;
}

export default function Header({ onZonaEliteClick }: HeaderProps) {
  const { theme, setTheme } = useTheme();

  const toggleTheme = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
  };

  const scrollToConfig = () => {
    const configSection = document.getElementById('vehicle-config');
    if (configSection) {
      configSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo and Brand */}
          <div className="flex items-center gap-3">
            <CarLogo size="md" />
            <div>
              <h1 className="font-display text-xl font-bold">
                <span className="gradient-text-gaming">Car Parking</span>
                <span className="text-primary">-Elite</span>
              </h1>
              <p className="text-xs text-muted-foreground hidden sm:block">
                Optimización Inteligente de Vehículos
              </p>
            </div>
          </div>

          {/* Navigation */}
          <nav className="hidden md:flex items-center gap-2">
            <Button 
              variant="ghost" 
              onClick={scrollToConfig}
              className="hover-elevate"
              data-testid="nav-configuration"
            >
              Configuración
            </Button>
            <Button 
              variant="ghost"
              onClick={onZonaEliteClick}
              className="hover-elevate"
              data-testid="nav-zona-elite"
            >
              <Settings className="w-4 h-4 mr-2" />
              ZONA-ELITE
            </Button>
          </nav>

          {/* Theme Toggle */}
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              className="hover-elevate"
              data-testid="button-theme-toggle"
            >
              {theme === 'light' ? (
                <Moon className="w-4 h-4" />
              ) : (
                <Sun className="w-4 h-4" />
              )}
              <span className="sr-only">Toggle theme</span>
            </Button>
            
            {/* Mobile ZONA-ELITE button */}
            <Button
              variant="ghost"
              size="icon"
              onClick={onZonaEliteClick}
              className="md:hidden hover-elevate"
              data-testid="button-zona-elite-mobile"
            >
              <Settings className="w-4 h-4" />
              <span className="sr-only">ZONA-ELITE</span>
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}