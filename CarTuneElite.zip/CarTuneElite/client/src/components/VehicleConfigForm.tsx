import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Upload, Car, Zap, Download } from 'lucide-react';

const vehicleConfigSchema = z.object({
  vehicleModel: z.string().min(1, 'El modelo del vehículo es requerido'),
  hp: z.number().min(1).max(2000),
  torque: z.number().min(1).max(5000),
  tyre: z.string().min(1, 'El tipo de llanta es requerido'),
  cd: z.number().min(0.1).max(2.0),
  drivingWheel: z.enum(['AWD', 'FWD', 'RWD']),
  brake: z.enum(['ABS', 'Standard', 'Racing']),
  shiftTime: z.number().min(0.1).max(2.0),
  turbo: z.boolean(),
  mileage: z.number().min(0).max(500000),
  drivingStyle: z.enum(['drift', 'speed', 'offroad', 'balanced']),
  trackType: z.enum(['circuit', 'drag', 'drift_track', 'offroad_course']),
  imageUrl: z.string().optional(),
  screenshotUrl: z.string().optional(),
});

type VehicleConfig = z.infer<typeof vehicleConfigSchema>;

export default function VehicleConfigForm() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<any>(null);

  const form = useForm<VehicleConfig>({
    resolver: zodResolver(vehicleConfigSchema),
    defaultValues: {
      vehicleModel: '',
      hp: 200,
      torque: 300,
      tyre: '',
      cd: 0.3,
      drivingWheel: 'AWD',
      brake: 'ABS',
      shiftTime: 0.5,
      turbo: false,
      mileage: 0,
      drivingStyle: 'balanced',
      trackType: 'circuit',
      imageUrl: '',
      screenshotUrl: '',
    }
  });

  const onSubmit = async (data: VehicleConfig) => {
    console.log('Analyzing vehicle configuration:', data);
    setIsAnalyzing(true);
    
    // Todo: Replace with real API call
    // Simulate analysis
    setTimeout(() => {
      const mockResult = {
        optimizedGearbox: `Gear Ratio: 1:${(data.hp / 100).toFixed(2)} - Configuración para ${data.drivingStyle}`,
        optimizedSuspension: `Dureza: ${data.drivingStyle === 'drift' ? 'Suave' : data.drivingStyle === 'speed' ? 'Media' : 'Dura'} - Altura: ${data.drivingStyle === 'offroad' ? 'Alta' : 'Baja'}`,
        optimizedCenterGravity: `Centro: ${data.drivingWheel === 'FWD' ? 'Adelante' : data.drivingWheel === 'RWD' ? 'Atrás' : 'Centrado'} - Estabilidad: ${data.cd < 0.3 ? 'Alta' : 'Media'}`,
        performance: Math.floor(data.hp * 0.8 + data.torque * 0.3),
      };
      setAnalysisResult(mockResult);
      setIsAnalyzing(false);
    }, 2000);
  };

  const handleImageUpload = (type: 'vehicle' | 'screenshot') => {
    console.log(`Upload ${type} image clicked`);
    // Todo: Implement image upload
  };

  const downloadConfig = () => {
    if (!analysisResult) return;
    
    const configData = {
      ...form.getValues(),
      ...analysisResult,
      timestamp: new Date().toISOString(),
    };
    
    const blob = new Blob([JSON.stringify(configData, null, 2)], {
      type: 'application/json',
    });
    
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${form.getValues().vehicleModel}_config.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    console.log('Configuration downloaded');
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-8">
      <Card className="hover-elevate">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-2xl">
            <Car className="w-6 h-6 text-primary" />
            Configuración del Vehículo
          </CardTitle>
          <CardDescription>
            Ingresa los datos de tu vehículo para generar la configuración optimizada
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {/* Vehicle Model and Images */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <FormField
                  control={form.control}
                  name="vehicleModel"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Modelo del Vehículo</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="ej. BMW M3, McLaren 720S" 
                          {...field} 
                          data-testid="input-vehicle-model"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="space-y-2">
                  <Label>Imagen del Vehículo</Label>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => handleImageUpload('vehicle')}
                    className="w-full hover-elevate"
                    data-testid="button-upload-vehicle-image"
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    Subir Imagen
                  </Button>
                </div>
                
                <div className="space-y-2">
                  <Label>Captura de Pantalla</Label>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => handleImageUpload('screenshot')}
                    className="w-full hover-elevate"
                    data-testid="button-upload-screenshot"
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    Subir Captura
                  </Button>
                </div>
              </div>

              {/* Performance Stats */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <FormField
                  control={form.control}
                  name="hp"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>HP (Caballos de Fuerza)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          {...field} 
                          onChange={(e) => field.onChange(parseInt(e.target.value))}
                          data-testid="input-hp"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="torque"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Torque</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          {...field} 
                          onChange={(e) => field.onChange(parseInt(e.target.value))}
                          data-testid="input-torque"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="mileage"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Kilometraje</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          {...field} 
                          onChange={(e) => field.onChange(parseInt(e.target.value))}
                          data-testid="input-mileage"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Technical Specs */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <FormField
                  control={form.control}
                  name="tyre"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tipo de Llanta</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="ej. Sports, Racing" 
                          {...field} 
                          data-testid="input-tyre"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="cd"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>CD (Coeficiente Aerodinámico)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          step="0.01" 
                          {...field} 
                          onChange={(e) => field.onChange(parseFloat(e.target.value))}
                          data-testid="input-cd"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="shiftTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tiempo de Cambio (s)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          step="0.1" 
                          {...field} 
                          onChange={(e) => field.onChange(parseFloat(e.target.value))}
                          data-testid="input-shift-time"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="turbo"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between space-y-0">
                      <FormLabel>Turbo</FormLabel>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          data-testid="switch-turbo"
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>

              {/* Drive Configuration */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="drivingWheel"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tracción</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-driving-wheel">
                            <SelectValue placeholder="Selecciona tipo de tracción" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="AWD">AWD - Tracción Integral</SelectItem>
                          <SelectItem value="FWD">FWD - Tracción Delantera</SelectItem>
                          <SelectItem value="RWD">RWD - Tracción Trasera</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="brake"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Sistema de Frenos</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-brake">
                            <SelectValue placeholder="Selecciona sistema de frenos" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="ABS">ABS</SelectItem>
                          <SelectItem value="Standard">Estándar</SelectItem>
                          <SelectItem value="Racing">Racing</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Driving Preferences */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="drivingStyle"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Estilo de Conducción</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-driving-style">
                            <SelectValue placeholder="Selecciona estilo" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="drift">Drift</SelectItem>
                          <SelectItem value="speed">Velocidad</SelectItem>
                          <SelectItem value="offroad">Off-road</SelectItem>
                          <SelectItem value="balanced">Balanceado</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="trackType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tipo de Pista</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-track-type">
                            <SelectValue placeholder="Selecciona tipo de pista" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="circuit">Circuito</SelectItem>
                          <SelectItem value="drag">Drag</SelectItem>
                          <SelectItem value="drift_track">Pista de Drift</SelectItem>
                          <SelectItem value="offroad_course">Curso Off-road</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <Button 
                type="submit" 
                size="lg" 
                disabled={isAnalyzing}
                className="w-full text-lg py-6 gradient-gaming hover-elevate"
                data-testid="button-analyze-vehicle"
              >
                <Zap className="w-5 h-5 mr-2" />
                {isAnalyzing ? 'Analizando...' : 'Analizar Configuración'}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>

      {/* Analysis Results */}
      {analysisResult && (
        <Card className="border-primary/50 hover-elevate">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-xl text-primary">
              <Zap className="w-5 h-5" />
              Configuración Optimizada
            </CardTitle>
            <CardDescription>
              Recomendaciones basadas en análisis inteligente
            </CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-muted/50 rounded-lg p-4">
                <h4 className="font-semibold text-foreground mb-2">Gearbox</h4>
                <p className="text-sm text-muted-foreground">{analysisResult.optimizedGearbox}</p>
              </div>
              
              <div className="bg-muted/50 rounded-lg p-4">
                <h4 className="font-semibold text-foreground mb-2">Suspensión</h4>
                <p className="text-sm text-muted-foreground">{analysisResult.optimizedSuspension}</p>
              </div>
              
              <div className="bg-muted/50 rounded-lg p-4">
                <h4 className="font-semibold text-foreground mb-2">Centro de Gravedad</h4>
                <p className="text-sm text-muted-foreground">{analysisResult.optimizedCenterGravity}</p>
              </div>
            </div>
            
            <div className="flex items-center justify-between pt-4 border-t border-border">
              <div className="text-sm text-muted-foreground">
                Puntuación de Rendimiento: <span className="font-bold text-primary">{analysisResult.performance}</span>
              </div>
              
              <Button 
                onClick={downloadConfig}
                variant="outline"
                className="hover-elevate"
                data-testid="button-download-config"
              >
                <Download className="w-4 h-4 mr-2" />
                Descargar Configuración
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}