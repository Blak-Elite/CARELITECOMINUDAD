import { Button } from '@/components/ui/button';
import { ArrowRight, Zap, Settings, Download } from 'lucide-react';
import heroImageUrl from '@assets/generated_images/Car_dashboard_hero_background_64d00b04.png';

export default function HeroSection() {
  const handleStartOptimizing = () => {
    console.log('Start optimizing clicked');
    // Todo: Scroll to vehicle configuration form
  };

  const handleZonaElite = () => {
    console.log('ZONA-ELITE access clicked');
    // Todo: Show admin login modal
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center">
      {/* Background Image with dark overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${heroImageUrl})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/80 to-background/95" />
      </div>

      {/* Hero Content */}
      <div className="relative z-10 max-w-4xl mx-auto text-center px-4">
        <h1 className="font-display text-4xl md:text-6xl font-bold text-foreground mb-6">
          <span className="gradient-text-gaming">Car Parking</span>
          <span className="text-primary">-Elite</span>
        </h1>
        
        <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
          Optimiza la configuración de tu vehículo en Car Parking Multiplayer con análisis inteligente de 
          <span className="text-primary font-medium"> Gearbox, Suspensión y Centro de Gravedad</span>
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
          <Button 
            size="lg" 
            className="text-lg px-8 py-6 gradient-gaming hover-elevate"
            onClick={handleStartOptimizing}
            data-testid="button-start-optimizing"
          >
            <Zap className="w-5 h-5 mr-2" />
            Comenzar Optimización
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
          
          <Button 
            variant="outline" 
            size="lg" 
            className="text-lg px-8 py-6 bg-background/20 backdrop-blur-sm hover-elevate"
            onClick={handleZonaElite}
            data-testid="button-zona-elite"
          >
            <Settings className="w-5 h-5 mr-2" />
            ZONA-ELITE
          </Button>
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-card/50 backdrop-blur-sm rounded-lg p-6 border border-card-border hover-elevate">
            <Settings className="w-8 h-8 text-primary mx-auto mb-4" />
            <h3 className="font-semibold text-foreground mb-2">Análisis Inteligente</h3>
            <p className="text-sm text-muted-foreground">
              Algoritmos avanzados para optimizar HP, Torque, Suspensión y más
            </p>
          </div>
          
          <div className="bg-card/50 backdrop-blur-sm rounded-lg p-6 border border-card-border hover-elevate">
            <Zap className="w-8 h-8 text-chart-2 mx-auto mb-4" />
            <h3 className="font-semibold text-foreground mb-2">Configuración Personalizada</h3>
            <p className="text-sm text-muted-foreground">
              Adaptado a tu estilo: Drift, Velocidad, Off-road y tipo de pista
            </p>
          </div>
          
          <div className="bg-card/50 backdrop-blur-sm rounded-lg p-6 border border-card-border hover-elevate">
            <Download className="w-8 h-8 text-chart-3 mx-auto mb-4" />
            <h3 className="font-semibold text-foreground mb-2">Descarga Instantánea</h3>
            <p className="text-sm text-muted-foreground">
              Archivos codificados listos para usar en el juego
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}