import logoUrl from '@assets/generated_images/Car_Parking_Elite_logo_230a7335.png';

interface CarLogoProps {
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export default function CarLogo({ size = 'md', className = '' }: CarLogoProps) {
  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-12 h-12',
    lg: 'w-16 h-16'
  };

  return (
    <img 
      src={logoUrl} 
      alt="Car Parking-Elite" 
      className={`${sizeClasses[size]} ${className}`}
      data-testid="logo-car-parking-elite"
    />
  );
}