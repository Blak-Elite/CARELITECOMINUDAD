import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { UserPlus, Users, CheckCircle, LogOut } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const addUserSchema = z.object({
  username: z.string().min(3, 'El nombre de usuario debe tener al menos 3 caracteres'),
  password: z.string().min(6, 'La contraseña debe tener al menos 6 caracteres'),
});

type AddUser = z.infer<typeof addUserSchema>;

interface User {
  id: string;
  username: string;
  createdAt: string;
}

interface AdminPanelProps {
  onLogout: () => void;
}

export default function AdminPanel({ onLogout }: AdminPanelProps) {
  const [users, setUsers] = useState<User[]>([
    // Todo: Remove mock data - replace with real users from API
    { id: '1', username: 'usuario_demo', createdAt: '2024-01-15' },
    { id: '2', username: 'player_001', createdAt: '2024-01-16' },
    { id: '3', username: 'tuning_expert', createdAt: '2024-01-17' },
  ]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const form = useForm<AddUser>({
    resolver: zodResolver(addUserSchema),
    defaultValues: {
      username: '',
      password: '',
    }
  });

  const onSubmit = async (data: AddUser) => {
    setIsSubmitting(true);
    console.log('Adding new user:', data);
    
    try {
      // Todo: Replace with real API call
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const newUser: User = {
        id: String(users.length + 1),
        username: data.username,
        createdAt: new Date().toISOString().split('T')[0],
      };
      
      setUsers(prev => [...prev, newUser]);
      form.reset();
      
      toast({
        title: 'Usuario agregado exitosamente',
        description: `El usuario "${data.username}" ha sido creado y puede acceder al sistema.`,
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'No se pudo agregar el usuario. Intente nuevamente.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-destructive/20 rounded-lg flex items-center justify-center">
              <Users className="w-5 h-5 text-destructive" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground">ZONA-ELITE</h1>
              <p className="text-sm text-muted-foreground">Panel de Administración</p>
            </div>
          </div>
          
          <Button 
            variant="outline" 
            onClick={onLogout}
            className="hover-elevate"
            data-testid="button-admin-logout"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Cerrar Sesión
          </Button>
        </div>
      </header>

      <div className="max-w-6xl mx-auto p-6 space-y-8">
        {/* Add User Form */}
        <Card className="hover-elevate">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-xl">
              <UserPlus className="w-5 h-5 text-primary" />
              Agregar Nuevo Usuario
            </CardTitle>
            <CardDescription>
              Crear credenciales de acceso para nuevos usuarios del sistema Car Parking-Elite
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Nombre de Usuario</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Ingrese nombre de usuario"
                            {...field}
                            data-testid="input-new-username"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Contraseña</FormLabel>
                        <FormControl>
                          <Input 
                            type="password"
                            placeholder="Ingrese contraseña"
                            {...field}
                            data-testid="input-new-password"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <Button 
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full md:w-auto gradient-gaming hover-elevate"
                  data-testid="button-add-user"
                >
                  <UserPlus className="w-4 h-4 mr-2" />
                  {isSubmitting ? 'Agregando...' : 'Agregar Usuario'}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>

        {/* Users Table */}
        <Card className="hover-elevate">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-xl">
              <Users className="w-5 h-5 text-chart-3" />
              Usuarios Registrados ({users.length})
            </CardTitle>
            <CardDescription>
              Lista de todos los usuarios con acceso al sistema
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            <div className="rounded-md border border-border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    <TableHead>ID</TableHead>
                    <TableHead>Usuario</TableHead>
                    <TableHead>Fecha de Registro</TableHead>
                    <TableHead>Estado</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.map((user) => (
                    <TableRow key={user.id} className="hover:bg-muted/30">
                      <TableCell className="font-mono text-sm">{user.id}</TableCell>
                      <TableCell className="font-medium">{user.username}</TableCell>
                      <TableCell className="text-muted-foreground">{user.createdAt}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-chart-3 border-chart-3/30">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Activo
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            
            {users.length === 0 && (
              <div className="text-center py-12">
                <Users className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-foreground mb-2">No hay usuarios</h3>
                <p className="text-muted-foreground">
                  Agregue el primer usuario usando el formulario de arriba
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Security Notice */}
        <Card className="border-destructive/30 bg-destructive/5 hover-elevate">
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-destructive/20 rounded-lg flex items-center justify-center flex-shrink-0 mt-1">
                <CheckCircle className="w-4 h-4 text-destructive" />
              </div>
              <div className="space-y-1">
                <h4 className="font-semibold text-foreground">Nota de Seguridad</h4>
                <p className="text-sm text-muted-foreground">
                  Todas las contraseñas se almacenan de forma segura utilizando encriptación BCrypt. 
                  Solo usuarios con credenciales ZONA-ELITE pueden acceder a este panel de administración.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}