import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Shield, Lock, AlertTriangle } from 'lucide-react';

const adminLoginSchema = z.object({
  identification: z.string().min(1, 'Identificación requerida'),
  username: z.string().min(1, 'Usuario requerido'),
  password: z.string().min(1, 'Contraseña requerida'),
});

type AdminLogin = z.infer<typeof adminLoginSchema>;

interface ZonaEliteLoginProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export default function ZonaEliteLogin({ isOpen, onClose, onSuccess }: ZonaEliteLoginProps) {
  const [attempts, setAttempts] = useState(0);
  const [isLocked, setIsLocked] = useState(false);

  const form = useForm<AdminLogin>({
    resolver: zodResolver(adminLoginSchema),
    defaultValues: {
      identification: '',
      username: '',
      password: '',
    }
  });

  const onSubmit = (data: AdminLogin) => {
    // Todo: Replace with actual validation against ADMIN_CREDENTIALS
    const isValid = 
      data.identification === 'NM03858' &&
      data.username === 'BLAK-ELITE' &&
      data.password === 'RELAMPAGO19543236@';
    
    if (isValid) {
      console.log('ZONA-ELITE access granted');
      onSuccess();
      form.reset();
      setAttempts(0);
    } else {
      const newAttempts = attempts + 1;
      setAttempts(newAttempts);
      console.log('ZONA-ELITE access denied, attempt:', newAttempts);
      
      if (newAttempts >= 3) {
        setIsLocked(true);
        setTimeout(() => {
          setIsLocked(false);
          setAttempts(0);
        }, 30000); // Lock for 30 seconds
      }
      
      form.setError('password', {
        type: 'manual',
        message: `Credenciales incorrectas. Intentos restantes: ${3 - newAttempts}`
      });
    }
  };

  const handleClose = () => {
    form.reset();
    setAttempts(0);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md bg-card border-2 border-destructive/20">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl text-destructive">
            <Shield className="w-6 h-6" />
            ZONA-ELITE
          </DialogTitle>
          <DialogDescription>
            Acceso restringido. Solo personal autorizado.
          </DialogDescription>
        </DialogHeader>

        {isLocked ? (
          <div className="text-center py-8">
            <Lock className="w-16 h-16 text-destructive mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-destructive mb-2">Acceso Bloqueado</h3>
            <p className="text-sm text-muted-foreground">
              Demasiados intentos fallidos. Intente nuevamente en 30 segundos.
            </p>
          </div>
        ) : (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="identification"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-foreground">Identificación</FormLabel>
                    <FormControl>
                      <Input 
                        type="text" 
                        placeholder="Ingrese identificación"
                        className="bg-background/50"
                        {...field}
                        data-testid="input-admin-identification"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-foreground">Usuario</FormLabel>
                    <FormControl>
                      <Input 
                        type="text" 
                        placeholder="Ingrese usuario"
                        className="bg-background/50"
                        {...field}
                        data-testid="input-admin-username"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-foreground">Contraseña</FormLabel>
                    <FormControl>
                      <Input 
                        type="password" 
                        placeholder="Ingrese contraseña"
                        className="bg-background/50"
                        {...field}
                        data-testid="input-admin-password"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {attempts > 0 && (
                <div className="flex items-center gap-2 p-3 bg-destructive/10 rounded-md border border-destructive/20">
                  <AlertTriangle className="w-4 h-4 text-destructive" />
                  <p className="text-sm text-destructive">
                    Credenciales incorrectas. {3 - attempts} intentos restantes.
                  </p>
                </div>
              )}

              <div className="flex gap-3">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={handleClose}
                  className="flex-1 hover-elevate"
                  data-testid="button-admin-cancel"
                >
                  Cancelar
                </Button>
                
                <Button 
                  type="submit" 
                  className="flex-1 bg-destructive hover:bg-destructive/90 hover-elevate"
                  disabled={isLocked}
                  data-testid="button-admin-login"
                >
                  <Shield className="w-4 h-4 mr-2" />
                  Acceder
                </Button>
              </div>
            </form>
          </Form>
        )}
      </DialogContent>
    </Dialog>
  );
}