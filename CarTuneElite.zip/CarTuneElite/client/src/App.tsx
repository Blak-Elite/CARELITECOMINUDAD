import { useState, useEffect } from 'react';
import { QueryClientProvider } from '@tanstack/react-query';
import { queryClient } from './lib/queryClient';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { ThemeProvider } from '@/components/ThemeProvider';
import Header from '@/components/Header';
import HeroSection from '@/components/HeroSection';
import VehicleConfigForm from '@/components/VehicleConfigForm';
import ZonaEliteLogin from '@/components/ZonaEliteLogin';
import AdminPanel from '@/components/AdminPanel';

type AppMode = 'main' | 'admin';

function App() {
  const [mode, setMode] = useState<AppMode>('main');
  const [showZonaEliteLogin, setShowZonaEliteLogin] = useState(false);

  // Force dark theme on mount
  useEffect(() => {
    document.documentElement.classList.add('dark');
  }, []);

  const handleZonaEliteClick = () => {
    setShowZonaEliteLogin(true);
  };

  const handleAdminLoginSuccess = () => {
    setShowZonaEliteLogin(false);
    setMode('admin');
  };

  const handleAdminLogout = () => {
    setMode('main');
  };

  if (mode === 'admin') {
    return (
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <ThemeProvider defaultTheme="dark">
            <AdminPanel onLogout={handleAdminLogout} />
            <Toaster />
          </ThemeProvider>
        </TooltipProvider>
      </QueryClientProvider>
    );
  }

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <ThemeProvider defaultTheme="dark">
          <div className="min-h-screen bg-background">
            <Header onZonaEliteClick={handleZonaEliteClick} />
            
            <main>
              <HeroSection />
              
              <section id="vehicle-config" className="py-16">
                <VehicleConfigForm />
              </section>
            </main>
            
            <footer className="bg-card/50 border-t border-border py-8 mt-16">
              <div className="max-w-4xl mx-auto px-6 text-center">
                <p className="text-muted-foreground">
                  © 2024 Car Parking-Elite. Sistema inteligente de optimización vehicular.
                </p>
              </div>
            </footer>
            
            <ZonaEliteLogin 
              isOpen={showZonaEliteLogin}
              onClose={() => setShowZonaEliteLogin(false)}
              onSuccess={handleAdminLoginSuccess}
            />
          </div>
          
          <Toaster />
        </ThemeProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
