import type { Express } from "express";
import express from 'express';
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertVehicleConfigurationSchema, loginSchema, adminLoginSchema } from "@shared/schema";
import { z } from "zod";
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { 
  generateToken, 
  ADMIN_CREDENTIALS, 
  authenticate, 
  adminAuth, 
  authRateLimit, 
  adminAuthRateLimit,
  type AuthenticatedRequest 
} from "./auth";

// Configure multer for image uploads
const uploadDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const upload = multer({
  storage: multer.diskStorage({
    destination: uploadDir,
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    },
  }),
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|gif/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  },
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB limit
});

// Intelligent analysis algorithm
function generateOptimizedConfiguration(config: any) {
  const { hp, torque, drivingStyle, trackType, cd, drivingWheel } = config;
  
  // Gearbox optimization
  let gearboxRatio = 1.0;
  if (drivingStyle === 'drift') {
    gearboxRatio = 0.8; // Shorter ratios for quick acceleration
  } else if (drivingStyle === 'speed') {
    gearboxRatio = 1.2; // Longer ratios for top speed
  } else if (drivingStyle === 'offroad') {
    gearboxRatio = 0.7; // Very short for torque
  }
  
  const finalGearRatio = gearboxRatio * (hp / 300); // Scale by HP
  
  // Suspension optimization
  let suspensionHardness = 'Media';
  let suspensionHeight = 'Baja';
  
  if (drivingStyle === 'drift') {
    suspensionHardness = 'Suave';
    suspensionHeight = 'Baja';
  } else if (drivingStyle === 'speed') {
    suspensionHardness = 'Dura';
    suspensionHeight = 'Muy Baja';
  } else if (drivingStyle === 'offroad') {
    suspensionHardness = 'Media';
    suspensionHeight = 'Alta';
  }
  
  // Center of gravity optimization
  let centerPosition = 'Centrado';
  let stability = 'Media';
  
  if (drivingWheel === 'FWD') {
    centerPosition = 'Adelante';
  } else if (drivingWheel === 'RWD') {
    centerPosition = 'Atrás';
  }
  
  if (cd < 0.3) {
    stability = 'Alta';
  } else if (cd > 0.5) {
    stability = 'Baja';
  }
  
  // Performance score calculation
  const baseScore = hp * 0.6 + torque * 0.4;
  const aerodynamicBonus = (1 - cd) * 100;
  const drivetrainBonus = drivingWheel === 'AWD' ? 50 : 0;
  const performanceScore = Math.floor(baseScore + aerodynamicBonus + drivetrainBonus);
  
  return {
    optimizedGearbox: `Relación: 1:${finalGearRatio.toFixed(2)} - Configuración para ${drivingStyle} en ${trackType}`,
    optimizedSuspension: `Dureza: ${suspensionHardness} - Altura: ${suspensionHeight} - Optimizado para ${drivingStyle}`,
    optimizedCenterGravity: `Centro: ${centerPosition} - Estabilidad: ${stability} - Aerodinámica: ${cd}`,
    performanceScore,
    recommendations: {
      gearbox: `Ajuste de relación de cambios optimizado para ${drivingStyle}`,
      suspension: `Configuración de suspensión balanceada para ${trackType}`,
      aerodynamics: cd < 0.3 ? 'Excelente aerodinámica' : 'Considera mejorar aerodinámica'
    }
  };
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Serve uploaded images
  app.use('/uploads', express.static(uploadDir));
  
  // Authentication endpoints with rate limiting
  app.post('/api/auth/register', authRateLimit, async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(409).json({ error: 'Usuario ya existe' });
      }
      
      const user = await storage.createUser(userData);
      const { password, ...userWithoutPassword } = user;
      
      // Generate JWT token for the new user
      const token = generateToken({
        userId: user.id,
        username: user.username,
        isAdmin: user.isAdmin || false
      });
      
      res.status(201).json({ 
        user: userWithoutPassword,
        token 
      });
    } catch (error) {
      console.error('Registration error:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: 'Datos inválidos', details: error.errors });
      }
      res.status(400).json({ error: 'Error al crear usuario' });
    }
  });
  
  app.post('/api/auth/login', authRateLimit, async (req, res) => {
    try {
      const validatedData = loginSchema.parse(req.body);
      
      const user = await storage.authenticateUser(validatedData.username, validatedData.password);
      if (!user) {
        return res.status(401).json({ error: 'Credenciales inválidas' });
      }
      
      // Generate JWT token
      const token = generateToken({
        userId: user.id,
        username: user.username,
        isAdmin: user.isAdmin || false
      });
      
      const { password: _, ...userWithoutPassword } = user;
      res.json({ 
        user: userWithoutPassword,
        token 
      });
    } catch (error) {
      console.error('Login error:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: 'Datos inválidos', details: error.errors });
      }
      res.status(500).json({ error: 'Error interno del servidor' });
    }
  });
  
  // Admin authentication endpoint with strict rate limiting
  app.post('/api/auth/admin-login', adminAuthRateLimit, async (req, res) => {
    try {
      const validatedData = adminLoginSchema.parse(req.body);
      
      const isValidAdmin = 
        validatedData.identification === ADMIN_CREDENTIALS.identification &&
        validatedData.username === ADMIN_CREDENTIALS.username &&
        validatedData.password === ADMIN_CREDENTIALS.password;
      
      if (!isValidAdmin) {
        return res.status(401).json({ error: 'Credenciales de administrador inválidas' });
      }
      
      // Generate JWT token for admin
      const token = generateToken({
        userId: 'admin',
        username: ADMIN_CREDENTIALS.username,
        isAdmin: true
      });
      
      res.json({ 
        success: true, 
        user: { 
          id: 'admin', 
          username: ADMIN_CREDENTIALS.username, 
          isAdmin: true 
        },
        token
      });
    } catch (error) {
      console.error('Admin login error:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: 'Datos inválidos', details: error.errors });
      }
      res.status(500).json({ error: 'Error interno del servidor' });
    }
  });
  
  // Vehicle configuration endpoints - requires authentication
  app.post('/api/vehicle-configurations', authenticate, upload.fields([{ name: 'vehicleImage' }, { name: 'screenshot' }]), async (req: AuthenticatedRequest, res) => {
    try {
      const configData = JSON.parse(req.body.configData || '{}');
      const validatedConfig = insertVehicleConfigurationSchema.parse(configData);
      
      // Handle uploaded files
      const files = req.files as { [fieldname: string]: Express.Multer.File[] };
      let imageUrl = '';
      let screenshotUrl = '';
      
      if (files.vehicleImage) {
        imageUrl = `/uploads/${files.vehicleImage[0].filename}`;
      }
      
      if (files.screenshot) {
        screenshotUrl = `/uploads/${files.screenshot[0].filename}`;
      }
      
      // Generate optimized configuration using AI algorithm
      const analysis = generateOptimizedConfiguration(validatedConfig);
      
      const configToSave = {
        ...validatedConfig,
        imageUrl,
        screenshotUrl,
        userId: req.user!.userId, // Get userId from authenticated JWT token
        optimizedGearbox: analysis.optimizedGearbox,
        optimizedSuspension: analysis.optimizedSuspension,
        optimizedCenterGravity: analysis.optimizedCenterGravity,
      };
      
      const savedConfig = await storage.createVehicleConfiguration(configToSave);
      
      res.json({
        configuration: savedConfig,
        analysis: {
          ...analysis,
          timestamp: new Date().toISOString(),
        }
      });
    } catch (error) {
      console.error('Configuration creation error:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: 'Datos inválidos', details: error.errors });
      }
      res.status(400).json({ error: 'Error al crear configuración' });
    }
  });
  
  app.get('/api/vehicle-configurations/:userId', async (req, res) => {
    try {
      const { userId } = req.params;
      const configurations = await storage.getUserVehicleConfigurations(userId);
      res.json({ configurations });
    } catch (error) {
      console.error('Get configurations error:', error);
      res.status(500).json({ error: 'Error al obtener configuraciones' });
    }
  });
  
  app.get('/api/vehicle-configurations/single/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const configuration = await storage.getVehicleConfiguration(id);
      
      if (!configuration) {
        return res.status(404).json({ error: 'Configuración no encontrada' });
      }
      
      res.json({ configuration });
    } catch (error) {
      console.error('Get single configuration error:', error);
      res.status(500).json({ error: 'Error al obtener configuración' });
    }
  });
  
  app.delete('/api/vehicle-configurations/:id', async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteVehicleConfiguration(id);
      res.json({ success: true });
    } catch (error) {
      console.error('Delete configuration error:', error);
      res.status(500).json({ error: 'Error al eliminar configuración' });
    }
  });
  
  // Admin user management endpoints
  app.post('/api/admin/users', async (req, res) => {
    try {
      // In a real app, verify admin JWT here
      const userData = insertUserSchema.parse(req.body);
      
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(409).json({ error: 'Usuario ya existe' });
      }
      
      const user = await storage.createUser(userData);
      const { password, ...userWithoutPassword } = user;
      
      res.status(201).json({ user: userWithoutPassword });
    } catch (error) {
      console.error('Admin user creation error:', error);
      res.status(400).json({ error: 'Error al crear usuario' });
    }
  });
  
  // Download configuration as JSON
  app.get('/api/vehicle-configurations/:id/download', async (req, res) => {
    try {
      const { id } = req.params;
      const configuration = await storage.getVehicleConfiguration(id);
      
      if (!configuration) {
        return res.status(404).json({ error: 'Configuración no encontrada' });
      }
      
      const downloadData = {
        vehicleModel: configuration.vehicleModel,
        specs: {
          hp: configuration.hp,
          torque: configuration.torque,
          tyre: configuration.tyre,
          cd: configuration.cd,
          drivingWheel: configuration.drivingWheel,
          brake: configuration.brake,
          shiftTime: configuration.shiftTime,
          turbo: configuration.turbo,
          mileage: configuration.mileage,
        },
        preferences: {
          drivingStyle: configuration.drivingStyle,
          trackType: configuration.trackType,
        },
        optimizedSettings: {
          gearbox: configuration.optimizedGearbox,
          suspension: configuration.optimizedSuspension,
          centerGravity: configuration.optimizedCenterGravity,
        },
        generatedAt: configuration.createdAt,
        platform: 'Car Parking-Elite'
      };
      
      res.setHeader('Content-Disposition', `attachment; filename="${configuration.vehicleModel}_config.json"`);
      res.setHeader('Content-Type', 'application/json');
      res.json(downloadData);
    } catch (error) {
      console.error('Download configuration error:', error);
      res.status(500).json({ error: 'Error al descargar configuración' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
