// Database storage implementation from javascript_database integration
import { users, vehicleConfigurations, type User, type InsertUser, type VehicleConfiguration, type InsertVehicleConfiguration } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";
import bcrypt from 'bcrypt';

// Enhanced interface with vehicle configuration methods
export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  authenticateUser(username: string, password: string): Promise<User | null>;
  
  // Vehicle configuration methods
  createVehicleConfiguration(config: InsertVehicleConfiguration & { userId: string }): Promise<VehicleConfiguration>;
  getUserVehicleConfigurations(userId: string): Promise<VehicleConfiguration[]>;
  getVehicleConfiguration(id: string): Promise<VehicleConfiguration | undefined>;
  updateVehicleConfiguration(id: string, updates: Partial<VehicleConfiguration>): Promise<VehicleConfiguration>;
  deleteVehicleConfiguration(id: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    // Hash password before storing
    const hashedPassword = await bcrypt.hash(insertUser.password, 12);
    
    const [user] = await db
      .insert(users)
      .values({
        ...insertUser,
        password: hashedPassword,
      })
      .returning();
    return user;
  }

  async authenticateUser(username: string, password: string): Promise<User | null> {
    const user = await this.getUserByUsername(username);
    if (!user) return null;
    
    const isValid = await bcrypt.compare(password, user.password);
    return isValid ? user : null;
  }

  // Vehicle configuration methods
  async createVehicleConfiguration(config: InsertVehicleConfiguration & { userId: string }): Promise<VehicleConfiguration> {
    const [vehicleConfig] = await db
      .insert(vehicleConfigurations)
      .values(config)
      .returning();
    return vehicleConfig;
  }

  async getUserVehicleConfigurations(userId: string): Promise<VehicleConfiguration[]> {
    return await db
      .select()
      .from(vehicleConfigurations)
      .where(eq(vehicleConfigurations.userId, userId));
  }

  async getVehicleConfiguration(id: string): Promise<VehicleConfiguration | undefined> {
    const [config] = await db
      .select()
      .from(vehicleConfigurations)
      .where(eq(vehicleConfigurations.id, id));
    return config || undefined;
  }

  async updateVehicleConfiguration(id: string, updates: Partial<VehicleConfiguration>): Promise<VehicleConfiguration> {
    const [updated] = await db
      .update(vehicleConfigurations)
      .set(updates)
      .where(eq(vehicleConfigurations.id, id))
      .returning();
    return updated;
  }

  async deleteVehicleConfiguration(id: string): Promise<void> {
    await db
      .delete(vehicleConfigurations)
      .where(eq(vehicleConfigurations.id, id));
  }
}

export const storage = new DatabaseStorage();
