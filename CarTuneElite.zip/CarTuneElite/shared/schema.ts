import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  isAdmin: boolean("is_admin").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const vehicleConfigurations = pgTable("vehicle_configurations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  vehicleModel: text("vehicle_model").notNull(),
  hp: integer("hp").notNull(),
  torque: integer("torque").notNull(),
  tyre: text("tyre").notNull(),
  cd: real("cd").notNull(),
  drivingWheel: text("driving_wheel").notNull(),
  brake: text("brake").notNull(),
  shiftTime: real("shift_time").notNull(),
  turbo: boolean("turbo").default(false),
  mileage: integer("mileage").notNull(),
  drivingStyle: text("driving_style").notNull(),
  trackType: text("track_type").notNull(),
  imageUrl: text("image_url"),
  screenshotUrl: text("screenshot_url"),
  optimizedGearbox: text("optimized_gearbox"),
  optimizedSuspension: text("optimized_suspension"),
  optimizedCenterGravity: text("optimized_center_gravity"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Login validation schemas
export const loginSchema = z.object({
  username: z.string().min(1, "Usuario requerido").max(50, "Usuario muy largo"),
  password: z.string().min(1, "Contraseña requerida"),
});

export const adminLoginSchema = z.object({
  identification: z.string().min(1, "Identificación requerida"),
  username: z.string().min(1, "Usuario requerido"),
  password: z.string().min(1, "Contraseña requerida"),
});

export const insertVehicleConfigurationSchema = createInsertSchema(vehicleConfigurations).omit({
  id: true,
  userId: true,
  optimizedGearbox: true,
  optimizedSuspension: true,
  optimizedCenterGravity: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertVehicleConfiguration = z.infer<typeof insertVehicleConfigurationSchema>;
export type VehicleConfiguration = typeof vehicleConfigurations.$inferSelect;

